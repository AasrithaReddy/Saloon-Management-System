function dialog()
{
	var name=document.getElementById("name").value;
    window.alert("Congrats, "+name+" ! You are now a member. You'll be contacted later for payment. Thankyou!");
    window.load("as.html");
}

function log()
{
	var username=document.getElementById("username").value;
	alert("Successfully logged in as "+username);
}
   function abc()
{
	var a;
    a=document.getElementById("names").value;
    window.alert("Mr/Ms."+a+",thanks for your feedback");
}
 
 function check1(){
 	var name=document.forms[0].name.value;
 	if (name==""){
 		document.getElementById("name").style.border="2px solid red";
 		document.getElementById("name").placeholder="Enter name!!";
 		
 	}
 	else
 		document.getElementById("name").style.border="1px solid #996633";
 	    ;
 }

function check2(){
 	var emailid=document.forms[0].emailid.value;
 	if (emailid==""){
 		document.getElementById("emailid").style.border="2px solid red";
 		document.getElementById("emailid").placeholder="Enter Email-Id!!";
 		
 	}
 	else
 		document.getElementById("emailid").style.border="1px solid #996633";
 	    ;
 }

 function check3(){
 	var username=document.forms[0].username.value;
 	if (username==""){
 		document.getElementById("username").style.border="2px solid red";
 		document.getElementById("username").placeholder="Enter username!!";
 		
 	}
 	else
 		document.getElementById("username").style.border="1px solid #996633";
 	    ;
 }

function check4(){
 	var plan=document.forms[0].plan.value;
 	if (plan=="Choose a plan"){
 		document.getElementById("plan").style.border="2px solid red"; 		
 	}
 	else
 		document.getElementById("plan").style.border="1px solid #996633";
 	    ;
 }

  function check5(){
 	var password=document.forms[0].password.value;
 	if (password==""){
 		document.getElementById("password").style.border="2px solid red";
 		document.getElementById("password").placeholder="Enter a Password!!";
 	}
 	else
 		document.getElementById("password").style.border="1px solid #996633";
 	    ;
 }
 function check6(){
 	var confirmpassword=document.forms[0].confirmpassword.value;
 	if (confirmpassword==""){
 		document.getElementById("confirmpassword").style.border="2px solid red";
 		document.getElementById("confirmpassword").placeholder="Enter Password again!!";
 	}
 	else
 		document.getElementById("confirmpassword").style.border="1px solid #996633";
 	    ;
 }
function validate(){
	var name=document.forms[0].name.value;
	var emailid=document.forms[0].emailid.value;
	var username=document.forms[0].username.value;
	var plan=document.forms[0].plan.value;
	var password=document.forms[0].password.value;
	var confirmpassword=document.forms[0].confirmpassword.value;
	var payment=document.forms[0].Payment.value;
	document.getElementById("name").style.border="1px solid #996633";
	document.getElementById("emailid").style.border="1px solid #996633";
	document.getElementById("username").style.border="1px solid #996633";
	document.getElementById("plan").style.border="1px solid #996633";
	document.getElementById("password").style.border="1px solid #996633";
	document.getElementById("confirmpassword").style.border="1px solid #996633";
    document.getElementById("username").style.border="1px solid #996633";
	if(name=="" || emailid=="" || username=="" || password=="")
	{
		alert("Please make sure to fill in all the fields");
		return false;
	}

	else 
	{
		if(plan=="Choose a plan"){
			alert("Choose a plan");
			return false;
		}
		else if(confirmpassword!=password)
		{
			alert("Make sure that both the entered passwords are same");
			return false;
		}
		else if(payment=="")
		{
			alert("Choose a valid payment option");
			return false;
		}
		else{
		dialog();
		return true;
	}}

    }
 
function validatess(){
	var username=document.forms[0].uname.value;
	var password=document.forms[0].lpassword.value;

	if(username=="" || password=="")
	{
		alert("Please fill in all the fields");
		return false;
	}

	else
	{
		log();
		return true;
	}
}

function check9(){
 	var username=document.forms[0].uname.value;
 	if (username==""){
 		document.getElementById("username").style.border="2px solid red";
 		document.getElementById("usermame").placeholder="Enter a username!!";
 	}
 	else
 		document.getElementById("username").style.border="1px solid #996633";
 	    ;
 }

 function check8(){
 	var password=document.forms[0].lpassword.value;
 	if (password==""){
 		document.getElementById("password").style.border="2px solid red";
 		document.getElementById("password").placeholder="Enter your password!!";
 	}
 	else
 		document.getElementById("password").style.border="1px solid #996633";
 	    ;
 }
